///**
// * 
// */
//package com.scg.beans;
//
//import java.beans.PropertyVetoException;
//import java.time.LocalDate;
//import com.scg.util.PersonalName;
//
///**
// * @author kailashm
// *
// */
//class HumanResourceManagerTest {
//
//	PersonalName personalName = new PersonalName("Mehta","Kail","BR");
//	
//	StaffConsultant staffConsultant = new StaffConsultant(personalName, 5, 5, 5);
//	
//	LocalDate effectiveDate = LocalDate.now();
//	
//	BenefitEvent benefitEvent = new BenefitEvent(staffConsultant, effectiveDate);
//	
//	TerminationEvent terminationEvent = new TerminationEvent(staffConsultant, staffConsultant, true);
//	
//	TerminationListener tListener;
//	
////	private final EventListenerList listenerList = new EventListenerList();
//	
//	HumanResourceManager humanResourceManager = new HumanResourceManager();
//	
//	BenefitManager          benMgr  = new BenefitManager();
//    HumanResourceManager    hrMgr   = new HumanResourceManager();
//    CompensationManager     comMgr  = new CompensationManager();
//    Eeoc                    eeoc    = new Eeoc();
//   
//	
//	void testHumanResourceManagerTest() throws PropertyVetoException {
//		humanResourceManager.addBenefitListener( benMgr );
//		humanResourceManager.acceptResignation(staffConsultant);
//		humanResourceManager.addTerminationListener(tListener);
//		humanResourceManager.terminate(staffConsultant);
//		
//		humanResourceManager.adjustPayRate(staffConsultant, 8);
//		
//		humanResourceManager.adjustPayRate(staffConsultant, 4);
//		humanResourceManager.adjustSickLeaveHours(staffConsultant, 8);
//		humanResourceManager.adjustVacationHours(staffConsultant, 6);
//		
//		humanResourceManager.enrollMedical(staffConsultant, effectiveDate);
//		staffConsultant.addPropertyChangeListener( benMgr );
//		humanResourceManager.cancelMedical(staffConsultant, effectiveDate);
//		humanResourceManager.enrollDental(staffConsultant, effectiveDate);
//		humanResourceManager.cancelDental(staffConsultant, effectiveDate);
//		
//	}
//}

package com.scg.beans;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyVetoException;
import java.beans.VetoableChangeListener;
import java.time.LocalDate;
import java.util.EventObject;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.scg.util.PersonalName;

import util.LogReader;

class HumanResourceManagerTest
{
    private static final String CHANGE_RATE = "Change pay rate".toLowerCase();
    private static final String APPROVED    = "approved".toLowerCase();
    private static final String VETOED      = "vetoed".toLowerCase();
    
    private StaffConsultant         consultant;
    private HumanResourceManager    mgr;
    private LogReader               reader;
    private BigShotListener         bsListener;
    private LocalDate               effectiveDate;

    @BeforeEach
    void setUp() throws Exception
    {
        PersonalName    name    = new PersonalName( "Twain", "Mark" );
        reader = new LogReader();
        consultant  = new StaffConsultant( name, 12000, 100, 100 );
        mgr         = new HumanResourceManager();
        bsListener = new BigShotListener();
        effectiveDate = LocalDate.now().plusDays( 5 );
    }

    @AfterEach
    void tearDown() throws Exception
    {
        if ( reader != null )
            reader.close();
    }

    @Test
    void testAcceptResignation()
    {
        mgr.addTerminationListener( bsListener );
        mgr.acceptResignation(consultant);
        assertTrue( bsListener.isVisited() );
        
        EventObject obj = bsListener.getEvent();
        assertTrue( obj instanceof TerminationEvent );
        
        TerminationEvent    event   = (TerminationEvent)obj;
        assertEquals( consultant, event.getConsultant() );
        assertTrue( event.isVoluntary() );
    }

    @Test
    void testTerminate()
    {
        mgr.addTerminationListener( bsListener );
        mgr.terminate(consultant);
        assertTrue( bsListener.isVisited() );
        
        EventObject obj = bsListener.getEvent();
        assertTrue( obj instanceof TerminationEvent );
        
        TerminationEvent    event   = (TerminationEvent)obj;
        assertEquals( consultant, event.getConsultant() );
        assertFalse( event.isVoluntary() );
    }

    @Test
    void testAdjustPayRate()
    {
        int     oldRate     = consultant.getPayRate();
        int     newRate     = oldRate + 1;
        String  line        = null;
        String  strCons     = consultant.toString().toLowerCase();
        consultant.addVetoableChangeListener( bsListener );
        
        mgr.adjustPayRate( consultant, newRate );
        assertEquals( newRate, consultant.getPayRate() );
        line = reader.nextMessage().toLowerCase();
        assertTrue( line.startsWith( CHANGE_RATE ), "Prefix missing" );
        assertTrue( line.contains( strCons ), "Consultant missing" );
        assertTrue( line.endsWith( APPROVED ), "'approved' missing" );
        
        bsListener.setMustVeto( true );
        oldRate = newRate;
        newRate += 1;
        mgr.adjustPayRate( consultant, newRate );
        bsListener.setMustVeto( false );
        assertEquals( oldRate, consultant.getPayRate() );
        line = reader.nextMessage().toLowerCase();
        assertTrue( line.startsWith( CHANGE_RATE ), "Prefix missing" );
        assertTrue( line.contains( strCons ), "Consultant missing" );
    }

    @Test
    void testAdjustSickLeaveHours()
    {
        int newHours    = consultant.getSickLeaveHours() + 1;
        mgr.adjustSickLeaveHours( consultant, newHours );
        assertEquals( newHours, consultant.getSickLeaveHours() );
    }

    @Test
    void testAdjustVacationHours()
    {
        int newHours    = consultant.getVacationHours() + 1;
        mgr.adjustVacationHours( consultant, newHours );
        assertEquals( newHours, consultant.getVacationHours() );
    }

    @Test
    void testEnrollMedical()
    {
        mgr.addBenefitListener( bsListener );
        mgr.enrollMedical( consultant, effectiveDate );

        EventObject obj = bsListener.getEvent();
        assertTrue( obj instanceof BenefitEvent );
        
        BenefitEvent        event       = (BenefitEvent)obj;
        Optional<Boolean>   medStatus   = event.medicalStatus();
        
        assertFalse( medStatus.isPresent() );
    }

    @Test
    void testCancelMedical()
    {
        mgr.addBenefitListener( bsListener );
        mgr.cancelMedical( consultant, effectiveDate );

        EventObject obj = bsListener.getEvent();
        assertTrue( obj instanceof BenefitEvent );
        
        BenefitEvent        event       = (BenefitEvent)obj;
        Optional<Boolean>   medStatus   = event.medicalStatus();
        Optional<Boolean>   dentStatus  = event.dentalStatus();
        
        assertTrue( medStatus.isPresent() );
        assertFalse( dentStatus.isPresent() );
        assertFalse( medStatus.get() );
        assertEquals( consultant, event.getConsultant() );
        assertEquals( effectiveDate, event.getEffectiveDate() );
    }

    @Test
    void testEnrollDental()
    {
        mgr.addBenefitListener( bsListener );
        mgr.enrollDental( consultant, effectiveDate );

        EventObject obj = bsListener.getEvent();
        assertTrue( obj instanceof BenefitEvent );
        
        BenefitEvent        event       = (BenefitEvent)obj;
        Optional<Boolean>   medStatus   = event.medicalStatus();
        Optional<Boolean>   dentStatus  = event.dentalStatus();
        
        assertFalse( medStatus.isPresent() );
        assertTrue( dentStatus.isPresent() );
        assertTrue( dentStatus.get() );
        assertEquals( consultant, event.getConsultant() );
        assertEquals( effectiveDate, event.getEffectiveDate() );
    }

    @Test
    void testCancelDental()
    {
        mgr.addBenefitListener( bsListener );
        mgr.cancelDental( consultant, effectiveDate );

        EventObject obj = bsListener.getEvent();
        assertTrue( obj instanceof BenefitEvent );
        
        BenefitEvent        event       = (BenefitEvent)obj;
        Optional<Boolean>   medStatus   = event.medicalStatus();
        Optional<Boolean>   dentStatus  = event.dentalStatus();
        
        assertFalse( medStatus.isPresent() );
        assertTrue( dentStatus.isPresent() );
        assertFalse( dentStatus.get() );
        assertEquals( consultant, event.getConsultant() );
        assertEquals( effectiveDate, event.getEffectiveDate() );
    }

    @Test
    void testAddTerminationListener()
    {
        mgr.addTerminationListener( bsListener );
        mgr.terminate( consultant );
        assertTrue( bsListener.isVisited() );
    }

    @Test
    void testRemoveTerminationListener()
    {
        mgr.addTerminationListener( bsListener );
        mgr.terminate( consultant );
        assertTrue( bsListener.isVisited() );
        
        bsListener.resetVisited();
        mgr.removeTerminationListener( bsListener );
        mgr.terminate( consultant );
        assertFalse( bsListener.isVisited() );
    }

    @Test
    void testAddBenefitListener()
    {
        mgr.addBenefitListener( bsListener );
        mgr.cancelDental( consultant, effectiveDate );
        assertTrue( bsListener.isVisited() );
    }

    @Test
    void testRemoveBenefitListener()
    {
        mgr.addBenefitListener( bsListener );
        mgr.cancelDental( consultant, effectiveDate );
        assertTrue( bsListener.isVisited() );
        
        bsListener.resetVisited();
        mgr.removeBenefitListener(bsListener);
        mgr.cancelMedical( consultant, effectiveDate );
        assertFalse( bsListener.isVisited() );
    }

    private class BigShotListener
        implements BenefitListener, TerminationListener, VetoableChangeListener
    {
        private boolean     mustVeto    = false;
        private boolean     visited     = false;
        private EventObject event       = null;
        @Override
        public void forcedTermination(TerminationEvent event)
        {
            visited = true;
            this.event = event;
        }

        @Override
        public void voluntaryTermination(TerminationEvent event)
        {
            visited = true;
            this.event = event;
        }

        @Override
        public void benefitChange(BenefitEvent event)
        {
            visited = true;
            this.event = event;
        }

        @Override
        public void vetoableChange(PropertyChangeEvent evt)
                throws PropertyVetoException
        {
            visited = true;
            this.event = event;
            if ( mustVeto )
                throw new PropertyVetoException( "",  evt );
        }
        
        public boolean isVisited()
        {
            return visited;
        }
        
        public void resetVisited()
        {
            visited = false;
        }
        
        public void setMustVeto( boolean veto )
        {
            mustVeto = veto;
        }
        
        public EventObject getEvent()
        {
            return event;
        }
    }
}
