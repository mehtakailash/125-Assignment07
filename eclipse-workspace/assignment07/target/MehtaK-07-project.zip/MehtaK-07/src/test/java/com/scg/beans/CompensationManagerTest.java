/**
 * 
 */
package com.scg.beans;

import org.junit.jupiter.api.Test;

/**
 * @author kailashm
 *
 */
class CompensationManagerTest {

	/**
	 * Test method for {@link com.scg.beans.CompensationManager#propertyChange(java.beans.PropertyChangeEvent)}.
	 */
	@Test
	void testPropertyChange() {
//		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.scg.beans.CompensationManager#vetoableChange(java.beans.PropertyChangeEvent)}.
	 */
	@Test
	void testVetoableChange() {
//		fail("Not yet implemented");
	}

}
